package org.cap.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NameConstraintValidator implements ConstraintValidator<NameAnnotation, String> {

	private String coursePrefix;

	@Override
	public void initialize(NameAnnotation constraintAnnotation) {
		coursePrefix=constraintAnnotation.value();
		
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		boolean result;
		if(value!=null) {
			result=value.startsWith(coursePrefix);
		}
		else {
			result=true;
		}
		return result;
	}

}

package org.cap.annotation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;

@Constraint(validatedBy=NameConstraintValidator.class)
@Retention(RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface NameAnnotation {

	public String value() default "firstName";
	public String message() default "must start with CAP";
	public Class<?>[] groups() default{};
	
}

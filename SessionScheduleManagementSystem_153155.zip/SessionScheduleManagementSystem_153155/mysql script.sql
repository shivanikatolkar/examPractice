USE spring;
CREATE TABLE ScheduledSessions(id int PRIMARY KEY,name VARCHAR(20),duration int,faculty VARCHAR(30),mode1 VARCHAR(20));

INSERT INTO ScheduledSessions VALUES(1,"Spring",4,"Vihar","ILT");
INSERT INTO ScheduledSessions VALUES(2,"Struts",4,"Tarun","ITL");
INSERT INTO ScheduledSessions VALUES(3,"Hibernate",3,"Rekha","VC");

package com.cg.schedule.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.schedule.beans.ScheduledSessions;

@Controller
public class URIController {
	
	
	@ModelAttribute("session")
	public ScheduledSessions getCourse()
	{
		return new ScheduledSessions();//returning attribute of ScheduledSessions
	}
}

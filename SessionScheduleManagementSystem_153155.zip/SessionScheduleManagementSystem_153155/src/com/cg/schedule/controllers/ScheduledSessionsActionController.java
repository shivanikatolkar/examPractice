package com.cg.schedule.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.schedule.beans.ScheduledSessions;
import com.cg.schedule.exceptions.ScheduledSessionsException;
import com.cg.schedule.services.IScheduledSessionsService;

@Controller
public class ScheduledSessionsActionController {

	@Autowired
	IScheduledSessionsService service;
	
	//requestMapping to home page(/) as ScheduledSessions.jsp(view to controller)
	@RequestMapping(value="/")
	public ModelAndView viewAllSessions()
	{
		List<ScheduledSessions> session;
		try {			
			session = service.viewSessions();
			//System.out.println(session);
			return new ModelAndView("ScheduledSessions","session",session);//at this breakpoint control goes to home page ScheduledSessions.jsp
		} 
		catch (ScheduledSessionsException e) {
			//exception message will be thrown if list is null!(controller to view)
			return new ModelAndView("ScheduledSessions","message",e.getMessage());
		}
		
	}
	
	//Request mapping from home page-ScheduledSessions url link 
	@RequestMapping(value="enroll")
	public ModelAndView enrollSession(@RequestParam("sessionName") String name)
	{
		if(name!=null)
			return new ModelAndView("Success","name",name);//it returns the control to Success.jsp page
		else
		{
			String error="Sorry!! Can not enroll now.";
			return new ModelAndView("ScheduledSessions","error",error);
		}
	}
	
}

package com.cg.schedule.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.schedule.beans.ScheduledSessions;

public interface IScheduledSessionsDAO extends JpaRepository<ScheduledSessions, Integer>{

}

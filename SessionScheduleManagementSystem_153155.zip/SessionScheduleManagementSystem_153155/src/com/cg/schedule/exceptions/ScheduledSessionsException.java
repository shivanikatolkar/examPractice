package com.cg.schedule.exceptions;

public class ScheduledSessionsException extends Exception{

	public ScheduledSessionsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ScheduledSessionsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ScheduledSessionsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ScheduledSessionsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ScheduledSessionsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}

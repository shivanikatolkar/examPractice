package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Pilot;
import org.cap.model.Users;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("pilotDao")

public class PilotDaoImpl implements IPilotDao {
	@PersistenceContext
private EntityManager entityManager;
	/*@Transactional
	@Override
	public void savePilot(Pilot pilot) {
		entityManager.persist(pilot);		
	}*/
	@Transactional(readOnly=true)
	@Override
	public List<Pilot> getAll() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList(); 
		//class name pilot
		return pilots;
	}
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
			}
	@Transactional
	@Override
	public void edit(Pilot pilot) 
     {
		Integer pilotId=pilot.getPilotId();
		Pilot pilot1= entityManager.find(Pilot.class, pilotId);

		if(pilot1==null)
		{
			entityManager.persist(pilot);
		}
		else {
			entityManager.merge(pilot);	
		}
	}
	@Transactional
	@Override
	public Pilot findPilot(Integer pilotId) {
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		//entityManager.remove(pilot);
		return pilot;
	}
	@Transactional
	@Override
	public boolean validate(String username, String password) {
			Users user=entityManager.find(Users.class, username);
		if(user!=null)
		if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
			return true;
		}
		return false;
	}

}

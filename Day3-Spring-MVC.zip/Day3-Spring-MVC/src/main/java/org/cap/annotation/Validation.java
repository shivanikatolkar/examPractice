package org.cap.annotation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;

@Constraint(validatedBy = PasswordConstraintValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD })
@Retention(RUNTIME)
public @interface Validation {

	public String value() default "password";
	public String message() default "must contain 1 alphabet";
	public Class<?>[] groups() default{};
	
}

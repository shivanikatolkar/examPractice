package org.cap.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordConstraintValidator implements ConstraintValidator<Validation, String> {
		
		@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		/*if(value!=null) {
			result=value.startsWith(coursePrefix);
		}
		else {
			result=true;
		}*/
		char c[]=value.toCharArray();
		for(int i=0;i<c.length;i++) {
			if(Character.isDigit(c[i])) {
				return true;
			}
		}
		
		return false;
	}

		@Override
		public void initialize(Validation constraintAnnotation) {
						
		}

}

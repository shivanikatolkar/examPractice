package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pilotService")
public class PilotServiceImpl implements IPilotService {
    @Autowired
    private IPilotDao pilotDao;
	/*@Override
	public void savePilot(Pilot pilot) {
		pilotDao.savePilot(pilot);
		
	}*/
	@Override
	public List<Pilot> getAll() {
				return pilotDao.getAll();
	}
	@Override
	public void delete(Integer pilotId) {
		pilotDao.delete(pilotId);
		
	}
	@Override
	public void edit(Pilot pilot1) {
		pilotDao.edit(pilot1);
	}
	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pilotDao.findPilot(pilotId);
	}
	@Override
	public boolean validate(String username, String password) {
		// TODO Auto-generated method stub
		return pilotDao.validate(username,password);
	}

}
